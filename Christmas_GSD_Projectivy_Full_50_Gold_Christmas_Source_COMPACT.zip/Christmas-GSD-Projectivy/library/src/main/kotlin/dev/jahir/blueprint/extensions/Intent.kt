package dev.jahir.blueprint.extensions

// Intent related stuff
const val PROJECTIVY_ACTION = "com.spocky.projengmenu.icons.ACTION_PICK_ICON"
const val ADW_ACTION = "org.adw.launcher.icons.ACTION_PICK_ICON"
const val TURBO_ACTION = "com.phonemetra.turbo.launcher.icons.ACTION_PICK_ICON"
const val NOVA_ACTION = "com.novalauncher.THEME"
const val APPLY_ACTION = "dev.jahir.blueprint.APPLY_ACTION"
const val ICONS_PICKER = 1
const val IMAGE_PICKER = 2
const val WALLS_PICKER = 3
const val ICONS_APPLIER = 4